package com.vortex.launcher.ui
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.tv.material3.Text
import com.vortex.launcher.MainViewModel
import com.vortex.launcher.data.*

private val Cities = listOf("Москва", "Санкт-Петербург", "Минск", "Киев", "Алматы", "Берлин", "Лондон")
private val Bg = Brush.verticalGradient(listOf(Color(0xFF0B1020), Color(0xFF1B1140)))

@Composable
fun SettingsScreen(vm: MainViewModel, st: Settings, nav: NavController) {
    fun onOff(b: Boolean) = if (b) "вкл" else "выкл"
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally,
            contentPadding = PaddingValues(32.dp)) {
            item { GlassButton("Скин: ${if (st.skin == "PS5") "Vortex Gaming" else "Vortex"}", { vm.setSkin(if (st.skin == "PS5") "APPLE" else "PS5") }, Modifier.autoFocus()) }
            item { GlassButton("Часы: положение ${listOf("лево", "центр", "право")[st.clockPos % 3]}", { vm.edit { it[K.CPOS] = (st.clockPos + 1) % 3 } }) }
            item { GlassButton("Часы: цвет ${st.clockColor % ClockColors.size + 1}/${ClockColors.size}", { vm.edit { it[K.CCOL] = (st.clockColor + 1) % ClockColors.size } }) }
            item { GlassButton("Часы: шрифт ${listOf("Sans", "Serif", "Mono")[st.clockFont % 3]}", { vm.edit { it[K.CFONT] = (st.clockFont + 1) % 3 } }) }
            item { GlassButton("Формат часов: ${if (st.clock24) "24ч" else "12ч"}", { vm.edit { it[K.C24] = !st.clock24 } }) }
            item { GlassButton("Док приложений", { nav.navigate("dock") }) }
            item { GlassButton("Профили", { nav.navigate("profiles") }) }
            item { GlassButton("Обои", { nav.navigate("wallpaperSettings") }) }
            item { GlassButton("Виджеты: ${onOff(st.widgets)}", { vm.edit { it[K.WIDGETS] = !st.widgets } }) }
            item { GlassButton("Погода: ${onOff(st.weather)}", { vm.edit { it[K.WEATHER] = !st.weather } }) }
            item { GlassButton("Город: ${st.city}", { vm.edit { it[K.CITY] = Cities[(Cities.indexOf(st.city) + 1) % Cities.size] } }) }
            item { GlassButton("Спрашивать профиль при включении: ${onOff(st.askProfile)}", { vm.edit { it[K.ASK] = !st.askProfile } }) }
        }
    }
}

@Composable
fun DockManager(vm: MainViewModel) {
    val apps by vm.apps.collectAsState()
    val prof by vm.active.collectAsState()
    val pinned = prof?.dockApps.orEmpty().split(",").filter { it.isNotBlank() }
    Column(Modifier.fillMaxSize().background(Bg).padding(32.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Док: выберите до 5 приложений (${pinned.size}/5)", color = Color.White, fontSize = 24.sp)
        LazyVerticalGrid(GridCells.Adaptive(130.dp)) {
            gridItems(apps) { a ->
                val on = a.pkg in pinned
                Box {
                    AppIcon(a, 64.dp, true, {
                        vm.setDock(if (on) pinned - a.pkg else if (pinned.size < 5) pinned + a.pkg else pinned)
                    }, modifier = Modifier.autoFocus().let { if (a == apps.first()) it else Modifier })
                    if (on) Text("📌", Modifier.align(Alignment.TopEnd), fontSize = 20.sp)
                }
            }
        }
    }
}

@Composable
fun ProfileManager(vm: MainViewModel) {
    val ps by vm.profiles.collectAsState()
    var editing by remember { mutableStateOf<Profile?>(null) }
    var creating by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        if (editing != null || creating) {
            ProfileEditor(editing, { n, i ->
                vm.saveProfile(editing?.copy(name = n, iconUri = i) ?: Profile(name = n, iconUri = i)); editing = null; creating = false
            }, { editing = null; creating = false })
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            items(ps) { p ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${p.iconUri ?: "🙂"} ${p.name}", color = Color.White, fontSize = 24.sp, modifier = Modifier.width(240.dp))
                    GlassButton("Переименовать", { editing = p }, if (p == ps.first()) Modifier.autoFocus() else Modifier)
                    if (ps.size > 1) GlassButton("Удалить", { vm.deleteProfile(p) })
                }
            }
            item { GlassButton("Создать профиль", { creating = true }) }
        }
    }
}
