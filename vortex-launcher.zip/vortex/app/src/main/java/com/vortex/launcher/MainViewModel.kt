package com.vortex.launcher
import android.content.Context
import android.content.Intent
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.datastore.preferences.core.MutablePreferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vortex.launcher.data.*
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val store: SettingsStore,
    private val dao: ProfileDao
) : ViewModel() {
    val settings: StateFlow<Settings?> = store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val profiles: StateFlow<List<Profile>> = dao.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val active: StateFlow<Profile?> = combine(profiles, settings) { ps, s ->
        ps.find { it.id == s?.activeProfile } ?: ps.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val homePress = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    init {
        viewModelScope.launch(Dispatchers.IO) {
            if (dao.count() == 0) dao.insert(Profile(name = "Основной", iconUri = "🙂"))
            apps.value = loadApps()
        }
    }
    // NonCancellable: запись должна завершиться, даже если Activity закрылась (ProfilePickerActivity)
    private fun run(b: suspend () -> Unit) { viewModelScope.launch(NonCancellable) { b() } }
    fun edit(b: (MutablePreferences) -> Unit) = run { store.update(b) }

    fun setSkin(s: String) = run {
        store.update { it[K.SKIN] = s }
        active.value?.let { dao.update(it.copy(skinType = s)) }
    }
    fun selectProfile(p: Profile, fromOnboarding: Boolean = false) = run {
        if (fromOnboarding) {
            val s = settings.value ?: Settings()
            dao.update(p.copy(skinType = s.skin, wallpaperUri = s.wallpaper))
            store.update { it[K.ACTIVE] = p.id }
        } else store.update {
            it[K.ACTIVE] = p.id; it[K.SKIN] = p.skinType; p.wallpaperUri?.let { w -> it[K.WALL] = w }
        }
    }
    fun saveProfile(p: Profile) = run { if (p.id == 0L) dao.insert(p) else dao.update(p) }
    fun deleteProfile(p: Profile) = run { if (profiles.value.size > 1) dao.delete(p) }
    fun setDock(pkgs: List<String>) = run { active.value?.let { dao.update(it.copy(dockApps = pkgs.joinToString(","))) } }
    fun setWallpaper(w: String) = run {
        store.update { it[K.WALL] = w }
        active.value?.let { dao.update(it.copy(wallpaperUri = w)) }
    }

    private fun loadApps(): List<AppInfo> {
        val pm = ctx.packageManager
        var l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        l = l + pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return l.filter { it.activityInfo.packageName != ctx.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()) }
            .sortedBy { it.label.lowercase() }
    }
}
