package com.vortex.launcher.ui
import android.Manifest
import android.content.Intent
import android.net.wifi.WifiManager
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.vortex.launcher.MainViewModel
import com.vortex.launcher.data.*
import kotlin.math.hypot
import kotlin.math.max

@Composable
fun OnbScaffold(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B1020), Color(0xFF1B1140)))).padding(48.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterVertically)
    ) {
        Text(title, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Light)
        content()
    }
}

@Composable
fun SplashScreen(onStart: () -> Unit) {
    val r = remember { Animatable(0f) }
    val a = remember { Animatable(0f) }
    var showBtn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        r.animateTo(1f, tween(1400, easing = FastOutSlowInEasing)); a.animateTo(1f, tween(900)); showBtn = true
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Canvas(Modifier.fillMaxSize()) {
            val m = max(1f, hypot(size.width, size.height) / 2 * r.value)
            drawCircle(Brush.radialGradient(listOf(Color(0xFF3A2A8F), Color(0xFF0B1020)), center, m), radius = m)
        }
        Text("Vortex Launcher", Modifier.align(Alignment.Center).graphicsLayer { alpha = a.value },
            style = TextStyle(color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.ExtraLight,
                shadow = Shadow(Color.White.copy(alpha = .7f), Offset.Zero, 28f)))
        AnimatedVisibility(showBtn, Modifier.align(Alignment.BottomCenter).padding(bottom = 64.dp),
            enter = fadeIn(tween(400)) + slideInVertically(tween<androidx.compose.ui.unit.IntOffset>(400)) { it }) {
            GlassButton("Начнём", onStart, Modifier.autoFocus())
        }
    }
}

@Composable
fun SkinScreen(onPick: (String) -> Unit) {
    OnbScaffold("Выберите интерфейс") {
        Row(horizontalArrangement = Arrangement.spacedBy(40.dp)) {
            SkinCard("Vortex", "Стиль Apple TV", listOf(Color(0xFF243B55), Color(0xFF734B6D)), Modifier.autoFocus()) { onPick("APPLE") }
            SkinCard("Vortex Gaming", "Стиль PS5", listOf(Color(0xFF001440), Color(0xFF00A8FF)), Modifier) { onPick("PS5") }
        }
    }
}
@Composable
private fun SkinCard(title: String, sub: String, g: List<Color>, m: Modifier, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.05f else 1f, spring(), label = "sk")
    val shape = RoundedCornerShape(24.dp)
    Column(m.graphicsLayer { scaleX = s; scaleY = s }.width(320.dp).clip(shape).background(Color.White.copy(alpha = .15f))
        .border(1.dp, Color.White.copy(alpha = if (f) 1f else .35f), shape)
        .onFocusChanged { f = it.isFocused }.clickable(onClick = onClick).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(g))) {
            Row(Modifier.align(Alignment.TopCenter).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(5) { Box(Modifier.size(24.dp).clip(RoundedCornerShape(6.dp)).background(Color.White.copy(alpha = .5f))) }
            }
        }
        Text(title, color = Color.White, fontSize = 24.sp); Text(sub, color = Color.White.copy(alpha = .7f), fontSize = 16.sp)
    }
}

@Composable
fun WifiScreen(onNext: () -> Unit) {
    val ctx = LocalContext.current
    var nets by remember { mutableStateOf(listOf<String>()) }
    fun scan() {
        nets = runCatching {
            ctx.getSystemService(WifiManager::class.java).scanResults.map { it.SSID }.filter { it.isNotBlank() }.distinct()
        }.getOrDefault(emptyList())
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { scan() }
    LaunchedEffect(Unit) { scan(); perm.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
    OnbScaffold("Wi-Fi") {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            // Подключение к сети из стороннего приложения ограничено (Android 10+), поэтому открываем системный экран Wi-Fi
            items(nets) { GlassButton("📶  $it", { ctx.startActivity(Intent(AndroidSettings.ACTION_WIFI_SETTINGS)) }) }
        }
        GlassButton("Пропустить", onNext, Modifier.autoFocus())
    }
}

@Composable
fun WallpaperPicker(current: String, onPick: (String) -> Unit, doneText: String, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            onPick(uri.toString())
        }
    }
    OnbScaffold("Обои") {
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.width(660.dp).height(240.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            itemsIndexed(Wallpapers) { i, g ->
                var f by remember { mutableStateOf(false) }
                val shape = RoundedCornerShape(16.dp)
                Box(Modifier.height(100.dp).clip(shape).background(Brush.linearGradient(g))
                    .border(if (current == "grad:$i" || f) 3.dp else 1.dp, Color.White.copy(alpha = if (f || current == "grad:$i") 1f else .3f), shape)
                    .onFocusChanged { f = it.isFocused }.clickable { onPick("grad:$i") })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            GlassButton("Загрузить свои", { pickFile.launch(arrayOf("image/*")) })
            GlassButton(doneText, onDone, Modifier.autoFocus())
        }
    }
}

@Composable
fun ExtrasScreen(st: Settings, vm: MainViewModel, onNext: () -> Unit) {
    OnbScaffold("Дополнительно") {
        GlassButton("Формат часов: ${if (st.clock24) "24ч" else "12ч"}", { vm.edit { it[K.C24] = !st.clock24 } }, Modifier.autoFocus())
        GlassButton("Погода: ${if (st.weather) "вкл" else "выкл"}", { vm.edit { it[K.WEATHER] = !st.weather } })
        GlassButton("Виджеты: ${if (st.widgets) "вкл" else "выкл"}", { vm.edit { it[K.WIDGETS] = !st.widgets } })
        GlassButton("Далее", onNext)
    }
}

@Composable
fun DefaultHomeScreen(onNext: () -> Unit) {
    val ctx = LocalContext.current
    OnbScaffold("Сделать Vortex основным?") {
        Text("Лаунчер будет открываться по кнопке Home", color = Color.White.copy(alpha = .7f), fontSize = 20.sp, textAlign = TextAlign.Center)
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            GlassButton("Поставить", { ctx.startActivity(Intent(AndroidSettings.ACTION_HOME_SETTINGS)); onNext() }, Modifier.autoFocus())
            GlassButton("Пропустить", onNext)
        }
    }
}

@Composable
fun ProfilePickerScreen(profiles: List<Profile>, onSelect: (Profile) -> Unit, onCreate: (String, String) -> Unit) {
    var creating by remember { mutableStateOf(false) }
    OnbScaffold("Кто смотрит?") {
        if (creating) ProfileEditor(null, { n, i -> onCreate(n, i); creating = false }, { creating = false })
        else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                items(profiles) { p -> GlassButton("${p.iconUri ?: "🙂"}  ${p.name}", { onSelect(p) }, if (p == profiles.first()) Modifier.autoFocus() else Modifier) }
            }
            GlassButton("Создать профиль", { creating = true })
        }
    }
}
