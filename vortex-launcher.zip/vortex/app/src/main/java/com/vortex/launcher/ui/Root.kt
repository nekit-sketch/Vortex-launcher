package com.vortex.launcher.ui
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.vortex.launcher.MainViewModel
import com.vortex.launcher.data.*

@Composable
fun VortexRoot(vm: MainViewModel) {
    val st = vm.settings.collectAsState().value ?: return
    val nav = rememberNavController()
    LaunchedEffect(Unit) { vm.homePress.collect { nav.popBackStack("home", false) } }
    val inT = { slideInHorizontally(tween<IntOffset>(300)) { it / 5 } + fadeIn(tween(300)) }
    val outT = { slideOutHorizontally(tween<IntOffset>(300)) { -it / 5 } + fadeOut(tween(300)) }
    NavHost(nav, startDestination = if (st.onboarded) "home" else "splash", modifier = Modifier.fillMaxSize().background(Color.Black),
        enterTransition = { inT() }, exitTransition = { outT() },
        popEnterTransition = { slideInHorizontally(tween<IntOffset>(300)) { -it / 5 } + fadeIn(tween(300)) },
        popExitTransition = { slideOutHorizontally(tween<IntOffset>(300)) { it / 5 } + fadeOut(tween(300)) }) {
        composable("splash") { SplashScreen { nav.navigate("skin") } }
        composable("skin") { SkinScreen { s -> vm.edit { it[K.SKIN] = s }; nav.navigate("wifi") } }
        composable("wifi") { WifiScreen { nav.navigate("wallpaper") } }
        composable("wallpaper") { WallpaperPicker(st.wallpaper, { w -> vm.edit { it[K.WALL] = w } }, "Далее") { nav.navigate("extras") } }
        composable("extras") { ExtrasScreen(st, vm) { nav.navigate("default") } }
        composable("default") { DefaultHomeScreen { nav.navigate("profile") } }
        composable("profile") {
            val ps by vm.profiles.collectAsState()
            ProfilePickerScreen(ps, { p ->
                vm.selectProfile(p, fromOnboarding = true); vm.edit { it[K.ONB] = true }
                nav.navigate("home") { popUpTo(0) }
            }, { n, i -> vm.saveProfile(Profile(name = n, iconUri = i)) })
        }
        composable("home") { HomeRoute(vm, st, nav) }
        composable("apps") { AllAppsScreen(vm) }
        composable("settings") { SettingsScreen(vm, st, nav) }
        composable("wallpaperSettings") { WallpaperPicker(st.wallpaper, { w -> vm.setWallpaper(w) }, "Готово") { nav.popBackStack() } }
        composable("dock") { DockManager(vm) }
        composable("profiles") { ProfileManager(vm) }
    }
}
