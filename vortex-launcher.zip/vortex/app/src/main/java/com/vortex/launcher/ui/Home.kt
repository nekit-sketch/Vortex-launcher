package com.vortex.launcher.ui
import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.provider.Settings as AndroidSettings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.tv.material3.Text
import com.vortex.launcher.MainViewModel
import com.vortex.launcher.data.*
import kotlinx.coroutines.delay

fun launchApp(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}
private val PsBlue = Color(0xFF00A8FF)

@Composable
fun HomeRoute(vm: MainViewModel, st: Settings, nav: NavController) {
    BackHandler(true) {}
    val apps by vm.apps.collectAsState()
    val prof by vm.active.collectAsState()
    var cc by remember { mutableStateOf(false) }
    val dock = prof?.dockApps.orEmpty().split(",").filter { it.isNotBlank() }
        .mapNotNull { p -> apps.find { it.pkg == p } }.take(5).ifEmpty { apps.take(5) }
    Box(Modifier.fillMaxSize()) {
        // «Морфинг» между скинами: scale + fade
        AnimatedContent(st.skin, transitionSpec = {
            (fadeIn(tween(500)) + scaleIn(tween(500), initialScale = .92f)) togetherWith (fadeOut(tween(300)) + scaleOut(tween(500), targetScale = 1.08f))
        }, label = "skin") { skin ->
            if (skin == "PS5") Ps5Home(st, apps, nav) { cc = true } else AppleHome(st, dock, nav) { cc = true }
        }
        AnimatedVisibility(cc, Modifier.align(Alignment.CenterEnd),
            enter = slideInHorizontally(spring<androidx.compose.ui.unit.IntOffset>(stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(),
            exit = slideOutHorizontally(tween<androidx.compose.ui.unit.IntOffset>(250)) { it } + fadeOut()) {
            BackHandler(true) { cc = false }
            ControlCenter(st, apps, onSettings = { cc = false; nav.navigate("settings") },
                onSwitch = { vm.setSkin(if (st.skin == "PS5") "APPLE" else "PS5"); cc = false })
        }
    }
}

@Composable
fun AppleHome(st: Settings, dock: List<AppInfo>, nav: NavController, onCC: () -> Unit) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize()) {
        WallpaperBg(st.wallpaper)
        // Часы: положение лево/центр/право (ВАЖНО: настоящий backdrop-blur стандартными средствами Compose недоступен — см. README)
        Box(Modifier.fillMaxWidth().padding(top = if (st.clockPos == 1) 124.dp else 28.dp, start = 32.dp, end = 32.dp),
            contentAlignment = when (st.clockPos) { 1 -> Alignment.TopCenter; 2 -> Alignment.TopEnd; else -> Alignment.TopStart }) {
            ClockPill(st)
        }
        Row(Modifier.align(Alignment.TopCenter).padding(top = 28.dp).clip(RoundedCornerShape(32.dp))
            .background(Color.White.copy(alpha = .14f)).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            dock.forEachIndexed { i, a -> AppIcon(a, 64.dp, false, { launchApp(ctx, a.pkg) }, 1.1f, false, if (i == 0) Modifier.autoFocus() else Modifier) }
            GlassButton("⋯", { nav.navigate("apps") })
        }
        Island(st, onCC, Modifier.align(Alignment.TopEnd).padding(28.dp))
        if (st.widgets) {
            LazyRow(Modifier.align(Alignment.TopCenter).padding(top = 190.dp), horizontalArrangement = Arrangement.spacedBy(20.dp),
                contentPadding = PaddingValues(horizontal = 48.dp)) {
                if (st.weather) item { WidgetCard { Text("☁ ${st.city}", color = Color.White, fontSize = 22.sp)
                    Text("— °C", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Light) } }
                item { val t by rememberTime(st.clock24); WidgetCard { Text("🕒", fontSize = 22.sp); Text(t, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Light) } }
                item { MediaWidget() }
            }
        }
    }
}

@Composable
fun Island(st: Settings, onClick: () -> Unit, modifier: Modifier) {
    var f by remember { mutableStateOf(false) }
    val t by rememberTime(st.clock24)
    Row(modifier.animateContentSize(spring(Spring.DampingRatioMediumBouncy)).clip(CircleShape)
        .background(Color.Black.copy(alpha = .45f)).border(1.dp, Color.White.copy(alpha = if (f) .9f else .3f), CircleShape)
        .onFocusChanged { f = it.isFocused }.clickable(onClick = onClick)
        .padding(horizontal = if (f) 24.dp else 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("📶", fontSize = 16.sp); Text(t, color = Color.White, fontSize = 16.sp)
        if (f) Text("Центр управления ›", color = Color.White, fontSize = 16.sp)
    }
}

@Composable
fun WidgetCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.width(240.dp).clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = .14f)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
}

@Composable
fun MediaWidget() {
    val ctx = LocalContext.current
    val c by produceState<android.media.session.MediaController?>(null) {
        while (true) {
            value = runCatching {
                ctx.getSystemService(MediaSessionManager::class.java)
                    .getActiveSessions(ComponentName(ctx, com.vortex.launcher.system.MediaListener::class.java)).firstOrNull()
            }.getOrNull()
            delay(2000)
        }
    }
    WidgetCard {
        val title = c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
        Text("🎵 " + (title ?: "Ничего не играет"), color = Color.White, fontSize = 18.sp, maxLines = 2)
        if (c == null) GlassButton("Доступ", { ctx.startActivity(Intent(AndroidSettings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        else Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            GlassButton("⏮", { c?.transportControls?.skipToPrevious() })
            GlassButton("⏯", { c?.transportControls?.let { tc -> if (c?.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) tc.pause() else tc.play() } })
            GlassButton("⏭", { c?.transportControls?.skipToNext() })
        }
    }
}

@Composable
fun ControlCenter(st: Settings, apps: List<AppInfo>, onSettings: () -> Unit, onSwitch: () -> Unit) {
    val ctx = LocalContext.current
    val t by rememberTime(st.clock24)
    var recents by remember { mutableStateOf(listOf<AppInfo>()) }
    LaunchedEffect(Unit) { recents = recentApps(ctx, apps) }
    Column(Modifier.fillMaxHeight().width(360.dp).background(Color(0xE61B1B2B)).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(t, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Light)
        GlassButton("📶 Wi-Fi", { ctx.startActivity(Intent(AndroidSettings.ACTION_WIFI_SETTINGS)) }, Modifier.autoFocus().fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassButton("⏻ Выкл.", { powerAction(ctx, false) }); GlassButton("↻ Перезагр.", { powerAction(ctx, true) })
        }
        Text("Недавние", color = Color.White.copy(alpha = .7f), fontSize = 16.sp)
        if (recents.isEmpty()) GlassButton("Выдать доступ к статистике", { ctx.startActivity(Intent(AndroidSettings.ACTION_USAGE_ACCESS_SETTINGS)) })
        recents.forEach { a ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppIcon(a, 40.dp, false, { launchApp(ctx, a.pkg) })
                Text(a.label, color = Color.White, fontSize = 16.sp, maxLines = 1, modifier = Modifier.weight(1f))
                GlassButton("✕", {
                    ctx.getSystemService(ActivityManager::class.java).killBackgroundProcesses(a.pkg)
                    recents = recents - a
                })
            }
        }
        Spacer(Modifier.weight(1f))
        GlassButton("Настройки лаунчера", onSettings, Modifier.fillMaxWidth())
        GlassButton(if (st.skin == "PS5") "Переключить на Vortex" else "Переключить на Gaming", onSwitch, Modifier.fillMaxWidth())
    }
}

/** getRecentTasks для сторонних приложений возвращает только собственные задачи, поэтому используем UsageStats (нужен спец. доступ). */
private fun recentApps(ctx: Context, apps: List<AppInfo>): List<AppInfo> = runCatching {
    val now = System.currentTimeMillis()
    ctx.getSystemService(UsageStatsManager::class.java).queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 86_400_000L, now)
        .sortedByDescending { it.lastTimeUsed }.mapNotNull { u -> apps.find { it.pkg == u.packageName } }.distinct().take(5)
}.getOrDefault(emptyList())

/** Выключение/перезагрузка доступны только системным приложениям или Device Owner (DevicePolicyManager.reboot). */
private fun powerAction(ctx: Context, reboot: Boolean) {
    runCatching {
        ctx.startActivity(Intent(Intent.ACTION_REQUEST_SHUTDOWN).putExtra("android.intent.extra.KEY_CONFIRM", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure { Toast.makeText(ctx, "Нужны права системного приложения или Device Owner", Toast.LENGTH_LONG).show() }
}

@Composable
fun Ps5Home(st: Settings, apps: List<AppInfo>, nav: NavController, onCC: () -> Unit) {
    val ctx = LocalContext.current
    val t by rememberTime(st.clock24)
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF001440), Color(0xFF00255F), Color(0xFF0A0F2C))))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 32.dp), verticalArrangement = Arrangement.spacedBy(36.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("VORTEX GAMING", color = PsBlue, fontSize = 22.sp, fontWeight = FontWeight.Light)
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(t, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Light)
                    GlassButton("Центр", onCC)
                }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(28.dp), contentPadding = PaddingValues(vertical = 24.dp)) {
                itemsIndexed12(apps.take(12)) { i, a -> AppIcon(a, 120.dp, true, { launchApp(ctx, a.pkg) }, 1.18f, true, if (i == 0) Modifier.autoFocus() else Modifier) }
                item { GlassButton("Все приложения", { nav.navigate("apps") }, Modifier.padding(top = 40.dp)) }
            }
        }
    }
}
private fun <T> androidx.compose.foundation.lazy.LazyListScope.itemsIndexed12(l: List<T>, c: @Composable (Int, T) -> Unit) =
    androidx.compose.foundation.lazy.itemsIndexed(l) { i, x -> c(i, x) }

@Composable
fun AllAppsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val apps by vm.apps.collectAsState()
    Box(Modifier.fillMaxSize().background(Color(0xF2101018))) {
        LazyVerticalGrid(GridCells.Adaptive(130.dp), contentPadding = PaddingValues(48.dp)) {
            gridItems(apps) { a -> AppIcon(a, 72.dp, true, { launchApp(ctx, a.pkg) }) }
        }
    }
}
