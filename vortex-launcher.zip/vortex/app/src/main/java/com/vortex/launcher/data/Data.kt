package com.vortex.launcher.data
import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Entity data class Profile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val iconUri: String? = null,
    val skinType: String = "APPLE",
    val wallpaperUri: String? = null,
    val dockApps: String = ""
)
@Dao interface ProfileDao {
    @Query("SELECT * FROM Profile ORDER BY id") fun all(): Flow<List<Profile>>
    @Query("SELECT COUNT(*) FROM Profile") suspend fun count(): Int
    @Insert suspend fun insert(p: Profile): Long
    @Update suspend fun update(p: Profile)
    @Delete suspend fun delete(p: Profile)
}
@Database(entities = [Profile::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() { abstract fun profiles(): ProfileDao }

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

data class Settings(
    val onboarded: Boolean = false, val skin: String = "APPLE", val clock24: Boolean = true,
    val weather: Boolean = true, val widgets: Boolean = true, val askProfile: Boolean = true,
    val wallpaper: String = "grad:0", val clockPos: Int = 0, val clockColor: Int = 0,
    val clockFont: Int = 0, val city: String = "Москва", val activeProfile: Long = 0
)
object K {
    val ONB = booleanPreferencesKey("onboarded"); val SKIN = stringPreferencesKey("skin")
    val C24 = booleanPreferencesKey("c24"); val WEATHER = booleanPreferencesKey("weather")
    val WIDGETS = booleanPreferencesKey("widgets"); val ASK = booleanPreferencesKey("ask")
    val WALL = stringPreferencesKey("wall"); val CPOS = intPreferencesKey("cpos")
    val CCOL = intPreferencesKey("ccol"); val CFONT = intPreferencesKey("cfont")
    val CITY = stringPreferencesKey("city"); val ACTIVE = longPreferencesKey("active")
}
private val Context.ds by preferencesDataStore("vortex")

@Singleton class SettingsStore @Inject constructor(@ApplicationContext private val ctx: Context) {
    val flow: Flow<Settings> = ctx.ds.data.map { p ->
        val d = Settings()
        Settings(p[K.ONB] ?: d.onboarded, p[K.SKIN] ?: d.skin, p[K.C24] ?: d.clock24, p[K.WEATHER] ?: d.weather,
            p[K.WIDGETS] ?: d.widgets, p[K.ASK] ?: d.askProfile, p[K.WALL] ?: d.wallpaper, p[K.CPOS] ?: d.clockPos,
            p[K.CCOL] ?: d.clockColor, p[K.CFONT] ?: d.clockFont, p[K.CITY] ?: d.city, p[K.ACTIVE] ?: d.activeProfile)
    }
    suspend fun update(b: (MutablePreferences) -> Unit) { ctx.ds.edit { b(it) } }
}
