package com.vortex.launcher.ui
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.view.SoundEffectConstants
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.vortex.launcher.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

fun Modifier.autoFocus(): Modifier = composed {
    val r = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { r.requestFocus() } }
    focusRequester(r)
}

/** Liquid glass: белая подложка 15%, скругление 24dp, обводка 1dp, при фокусе ярче + 1.05x */
@Composable
fun GlassButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.05f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "gb")
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier.graphicsLayer { scaleX = s; scaleY = s }
            .clip(shape).background(Color.White.copy(alpha = .15f))
            .border(1.dp, Color.White.copy(alpha = if (f) 1f else .35f), shape)
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 32.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 20.sp) }
}

@Composable
fun AppIcon(app: AppInfo, size: Dp, showLabel: Boolean, onClick: () -> Unit,
            focusScale: Float = 1.1f, tilt: Boolean = false, modifier: Modifier = Modifier) {
    var f by remember { mutableStateOf(false) }
    val view = LocalView.current
    val sc by animateFloatAsState(if (f) focusScale else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "sc")
    val rot by animateFloatAsState(if (f && tilt) -6f else 0f, spring(), label = "rot")
    Column(
        modifier.graphicsLayer { scaleX = sc; scaleY = sc; rotationY = rot; cameraDistance = 12f * density }
            .onFocusChanged { f = it.isFocused; if (it.isFocused && tilt) view.playSoundEffect(SoundEffectConstants.NAVIGATION_RIGHT) }
            .clip(RoundedCornerShape(18.dp))
            .border(2.dp, if (f) Color.White else Color.Transparent, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(app.icon, null, Modifier.size(size))
        if (showLabel) Text(app.label, color = Color.White, fontSize = 14.sp, maxLines = 1)
    }
}

val Wallpapers = listOf(
    listOf(Color(0xFF141E30), Color(0xFF243B55)), listOf(Color(0xFF42275A), Color(0xFF734B6D)),
    listOf(Color(0xFF0F2027), Color(0xFF2C5364)), listOf(Color(0xFFFF512F), Color(0xFFDD2476)),
    listOf(Color(0xFF134E5E), Color(0xFF71B280)), listOf(Color(0xFF000428), Color(0xFF004E92))
)
@Composable
fun WallpaperBg(w: String) {
    if (w.startsWith("grad:")) {
        val g = Wallpapers[(w.removePrefix("grad:").toIntOrNull() ?: 0).coerceIn(0, Wallpapers.lastIndex)]
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(g)))
    } else {
        val ctx = LocalContext.current
        val bmp by produceState<ImageBitmap?>(null, w) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    ctx.contentResolver.openInputStream(Uri.parse(w))!!.use {
                        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 })!!.asImageBitmap()
                    }
                }.getOrNull()
            }
        }
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            ?: Box(Modifier.fillMaxSize().background(Color.Black))
    }
}

@Composable
fun rememberTime(is24: Boolean): State<String> = produceState("", is24) {
    val fmt = SimpleDateFormat(if (is24) "HH:mm" else "h:mm a", Locale.getDefault())
    while (true) { value = fmt.format(Date()); delay(1000) }
}

val ClockColors = listOf(Color.White, Color(0xFF7DD3FC), Color(0xFFFCA5A5), Color(0xFFA7F3D0))
val ClockFonts = listOf(FontFamily.SansSerif, FontFamily.Serif, FontFamily.Monospace)

@Composable
fun ClockPill(st: Settings, modifier: Modifier = Modifier) {
    val t by rememberTime(st.clock24)
    Box(modifier.clip(RoundedCornerShape(28.dp)).background(Color.White.copy(alpha = .12f))
        .padding(horizontal = 28.dp, vertical = 6.dp)) {
        Text(t, color = ClockColors[st.clockColor % ClockColors.size], fontSize = 56.sp,
            fontWeight = FontWeight.Thin, fontFamily = ClockFonts[st.clockFont % ClockFonts.size])
    }
}

val AvatarIcons = listOf("🙂", "😎", "🎮", "🧒", "🐱", "🚀")

@Composable
fun ProfileEditor(initial: Profile?, onSave: (String, String) -> Unit, onCancel: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var icon by remember { mutableStateOf(initial?.iconUri ?: AvatarIcons.first()) }
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        BasicTextField(name, { name = it }, textStyle = TextStyle(color = Color.White, fontSize = 28.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier.autoFocus().width(360.dp)
                .border(1.dp, Color.White.copy(alpha = .5f), RoundedCornerShape(16.dp)).padding(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AvatarIcons.forEach { e -> GlassButton(if (e == icon) "[$e]" else e, { icon = e }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            GlassButton("Сохранить", { if (name.isNotBlank()) onSave(name.trim(), icon) })
            GlassButton("Отмена", onCancel)
        }
    }
}

@Composable
fun VolumeOverlay(level: Int, stamp: Long) {
    var vis by remember { mutableStateOf(false) }
    LaunchedEffect(stamp) { if (stamp > 0) { vis = true; delay(1600); vis = false } }
    Box(Modifier.fillMaxSize().padding(end = 32.dp), contentAlignment = Alignment.CenterEnd) {
        AnimatedVisibility(vis, enter = slideInHorizontally(tween<androidx.compose.ui.unit.IntOffset>(250)) { it } + fadeIn(tween(250)),
            exit = slideOutHorizontally(tween<androidx.compose.ui.unit.IntOffset>(250)) { it } + fadeOut(tween(250))) {
            Box(Modifier.width(64.dp).height(280.dp).clip(RoundedCornerShape(32.dp)).background(Color.White.copy(alpha = .25f))) {
                Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(level / 25f).background(Color.White))
                Text("$level", color = Color.Black.copy(alpha = .6f), modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp), fontSize = 16.sp)
            }
        }
    }
}
