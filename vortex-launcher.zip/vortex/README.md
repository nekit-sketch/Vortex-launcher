# Vortex Launcher
Сборка: push в GitHub → Actions → артефакт `vortex-launcher-debug-apk` (debug-ключ подставляется Gradle автоматически).
Локально: `gradle :app:assembleDebug` (Gradle 8.7, JDK 17). Gradle wrapper не включён — workflow ставит Gradle сам; для локального wrapper выполните `gradle wrapper`.
Проект НЕ компилировался в среде, где был написан: возможны мелкие правки импортов/версий при первой сборке.

## Сторонние виджеты (AppWidgetHost)
1. `val host = AppWidgetHost(ctx, 1024)`, `val mgr = AppWidgetManager.getInstance(ctx)`; `host.startListening()` в onStart, `stopListening()` в onStop.
2. `id = host.allocateAppWidgetId()`; выбор провайдера: `Intent(ACTION_APPWIDGET_PICK)` либо свой список из `mgr.installedProviders`.
3. Привязка: `mgr.bindAppWidgetIdIfAllowed(id, provider)`; если false — `Intent(ACTION_APPWIDGET_BIND)` с EXTRA_APPWIDGET_ID/PROVIDER; затем настройка через `ACTION_APPWIDGET_CONFIGURE`, если у провайдера есть configure.
4. Показ: `AndroidView({ host.createView(ctx, id, info) })` в LazyRow виджетов. Id и порядок хранить в DataStore/Room.
Ограничение: на многих Android TV нет системного выбора виджетов и виджеты почти не поставляются.

## Звуки (SoundPool)
`SoundPool.Builder().setMaxStreams(4).build()`, `load(ctx, R.raw.move, 1)` для файлов в `res/raw`; в `AppIcon` при фокусе вызывать `play(id, .6f, .6f, 1, 0, 1f)`. Сейчас используется системный `view.playSoundEffect(NAVIGATION_RIGHT)` (без ассетов).

## Ограничения
- Выключение/перезагрузка: только системное приложение или Device Owner (`DevicePolicyManager.reboot`); иначе кнопка покажет сообщение.
- Недавние приложения: `getRecentTasks` недоступен сторонним приложениям, используется UsageStats (спец. доступ «Статистика использования»).
- Blur: `Modifier.blur`/`RenderEffect` размывают сам элемент, а не фон за ним. Для «стекла» используется полупрозрачная подложка; настоящий backdrop-blur требует отдельного размытого слоя обоев под плашкой.
- Wi-Fi: подключение из стороннего приложения ограничено, список сетей — через scanResults, выбор открывает системный экран.
- Музыка: нужен «Доступ к уведомлениям» для `MediaListener`.
- Автозапуск выбора профиля из BOOT_COMPLETED может блокироваться ограничениями запуска Activity из фона на части прошивок.
- Не реализованы: реальная погода (виджет-заглушка, подключить Open-Meteo), порядок виджетов, drag-reorder дока.
